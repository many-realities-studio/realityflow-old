export interface IMidiEvent {
    _from?: string;
    _id?: string;
    type: number;
    number: number;
    name: string;
    octave: number;
}
